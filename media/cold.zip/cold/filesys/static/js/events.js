function click() {
	print "click"
}