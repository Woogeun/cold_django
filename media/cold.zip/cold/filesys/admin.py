# -*- coding: utf-8 -*-

from django.contrib import admin
from .models import UploadFileModel

admin.site.register(UploadFileModel)

# Register your models here.
